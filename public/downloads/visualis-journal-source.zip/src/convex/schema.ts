import { authTables } from "@convex-dev/auth/server";
import { defineSchema, defineTable } from "convex/server";
import { Infer, v } from "convex/values";

// default user roles. can add / remove based on the project as needed
export const ROLES = {
  ADMIN: "admin",
  USER: "user",
  MEMBER: "member",
} as const;

export const roleValidator = v.union(
  v.literal(ROLES.ADMIN),
  v.literal(ROLES.USER),
  v.literal(ROLES.MEMBER),
);
export type Role = Infer<typeof roleValidator>;

const schema = defineSchema(
  {
    // default auth tables using convex auth.
    ...authTables, // do not remove or modify

    // the users table is the default users table that is brought in by the authTables
    users: defineTable({
      name: v.optional(v.string()), // name of the user. do not remove
      image: v.optional(v.string()), // image of the user. do not remove
      email: v.optional(v.string()), // email of the user. do not remove
      emailVerificationTime: v.optional(v.number()), // email verification time. do not remove
      isAnonymous: v.optional(v.boolean()), // is the user anonymous. do not remove

      role: v.optional(roleValidator), // role of the user. do not remove
    }).index("email", ["email"]), // index for the email. do not remove or modify

    // journal posts written in the studio
    posts: defineTable({
      title: v.string(),
      slug: v.string(),
      excerpt: v.string(),
      body: v.string(),
      tags: v.array(v.string()),
      cover: v.string(),
      author: v.string(),
      readMinutes: v.number(),
      status: v.union(v.literal("draft"), v.literal("published")),
      publishedAt: v.number(),
      updatedAt: v.number(),
      authorId: v.optional(v.id("users")),
    })
      .index("by_slug", ["slug"])
      .index("by_status", ["status"])
      .index("by_published", ["publishedAt"]),

    // member-only downloadable working files
    resources: defineTable({
      title: v.string(),
      slug: v.string(),
      description: v.string(),
      category: v.string(),
      fileType: v.union(v.literal("md"), v.literal("csv")),
      fileName: v.string(),
      content: v.string(),
      order: v.number(),
      downloadCount: v.number(),
      updatedAt: v.number(),
    }).index("by_slug", ["slug"]),
  },
  {
    schemaValidation: false,
  },
);

export default schema;
